export class Professor {
    nome: string;

    constructor(nome: string) {
      this.nome = nome;
    }
}
