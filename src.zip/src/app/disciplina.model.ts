
export class Disciplina {
    codigo: number;
    nome: string;
    descricao: string;
    data: Date;
    veio: boolean;
    tipo: boolean;
    tipoocorrencia: string;
    nomeresp: string;

    // tslint:disable-next-line:max-line-length
    constructor(codigo: number, nome: string,  descricao: string, data: Date, veio: boolean, tipo: boolean,  tipoocorrencia?: string, nomeresp?: string) {
      this.codigo = codigo;
      this.nome = nome;
      this.descricao = descricao;
      this.data = data;
      this.veio = veio;
      this.tipo = tipo;
      this.tipoocorrencia = tipoocorrencia;
    }
}
